import turtle
def draw_hexagon(t, length):
    for _ in range(6):
        t.forward(length)
        t.right(60)
def draw_four_hexagons():
    t = turtle.Turtle()
    t.speed(0)
    t.pensize(2)
    length = 80
    offset = 90
    positions = [(-offset, offset), (offset, offset), (-offset, -offset), (offset, -offset)]
    for (x, y) in positions:
        t.penup()
        t.goto(x, y)
        t.pendown()
        draw_hexagon(t, length)
    turtle.done()
draw_four_hexagons()
