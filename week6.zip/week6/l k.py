import tkinter as tk
from tkinter import messagebox
def calculate():
    try:
        qty = int(quantity_entry.get())
        if qty < 0:
            messagebox.showerror("Error", "Enter a valid number")
            return
        price = 99
        subtotal = qty * price
        if 10 <= qty <= 19:
            disc = 0.10
        elif 20 <= qty <= 49:
            disc = 0.20
        elif 50 <= qty <= 99:
            disc = 0.30
        elif qty >= 100:
            disc = 0.40
        else:
            disc = 0.0
        discount_amt = subtotal * disc
        total = subtotal - discount_amt
        discount_label.config(text=f"Discount: ${discount_amt:.2f}")
        total_label.config(text=f"Total: ${total:.2f}")
    except ValueError:
        messagebox.showerror("Error", "Enter a number")
window = tk.Tk()
window.title("UC Software Sales Discount")
window.geometry("400x220")
tk.Label(window, text="Student Information Management System", font=("Arial", 12)).pack(pady=8)
tk.Label(window, text="Packages Purchased:").pack()
quantity_entry = tk.Entry(window)
quantity_entry.pack(pady=4)
tk.Button(window, text="Calculate", command=calculate).pack(pady=8)
discount_label = tk.Label(window, text="Discount: $0.00", font=("Arial", 11))
discount_label.pack()
total_label = tk.Label(window, text="Total: $0.00", font=("Arial", 11, "bold"))
total_label.pack(pady=4)
window.mainloop()
