import matplotlib.pyplot as plt
from keras.preprocessing.image import load_img
from keras.preprocessing.image import save_img
from keras.preprocessing.image import img_to_array

img_path = "1_Gammar 2021_1_2021_06_03-13-19-23-856.PNG"
img = load_img(img_path, color_mode='grayscale')
img_array = img_to_array(img)

save_img("insect_grayscale.PNG", img_array)
img = load_img("insect_grayscale.PNG")

print(type(img))
print(img.format)
print(img.mode)
print(img.size)

plt.imshow(img, cmap='gray')
plt.axis('off')
plt.show()
