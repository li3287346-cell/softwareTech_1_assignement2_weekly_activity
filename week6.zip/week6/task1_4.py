from keras.datasets import mnist

(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

print('Train', train_images.shape, train_labels.shape)
print('Test', test_images.shape, test_labels.shape)

print('Train', train_images.min(), train_images.max(), train_images.mean(), train_images.std())
print('Test', test_images.min(), test_images.max(), test_images.mean(), test_images.std())
